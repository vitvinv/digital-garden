"""Part drawing — ports the PlantStudio part draw() methods to the MeshTurtle.

Each part draws itself into the turtle's mesh buffer:
- internode: stem pipe (tapered, curved segments)
- leaf: petiole pipe + leaf TDO (or compound leaflets)
- meristem/inflorescence/flower: TDO objects (buds, petals)
"""

from . import math3d as umath
from .meristem import (kDirectionLeft, kDirectionRight, kArrangementOpposite,
                       kActivityDraw)
from .traverser import PdTraverser

kDontTaper = 0
kUseAmendment = 1

# plant part export indices (used for material naming)
kExportPartInternode = 1
kExportPartLeaf = 2
kExportPartLeafStipule = 3
kExportPartPetiole = 4
kExportPartMeristem = 5
kExportPartRootTop = 6
kExportPartInflorescence = 7
kExportPartFlower = 8
kExportPartFruit = 9

PART_NAMES = {
    kExportPartInternode: "internode",
    kExportPartLeaf: "leaf",
    kExportPartLeafStipule: "stipule",
    kExportPartPetiole: "petiole",
    kExportPartMeristem: "meristem",
    kExportPartRootTop: "root",
    kExportPartInflorescence: "inflorescence",
    kExportPartFlower: "flower",
    kExportPartFruit: "fruit",
}


def _gp(obj, name, default=0.0):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def resolve_tdo(plant, tdo):
    """Resolve a TDO reference (Tdo object or name string) via the library."""
    if tdo is None:
        return None
    if isinstance(tdo, str):
        lib = getattr(plant, "tdoLibrary", None)
        if lib is not None:
            return lib.get(tdo)
        return None
    return tdo


class DrawContext:
    """Holds state while drawing a plant."""

    def __init__(self, turtle):
        self.turtle = turtle
        self.materials = {}  # name -> color


def draw_plant(plant, turtle):
    """Draw the whole plant into the turtle's mesh buffer."""
    plant.turtle = turtle
    if plant.firstPhytomer is not None:
        traverser = PdTraverser(plant)
        traverser.traverseWholePlant(kActivityDraw)
    plant.turtle = None


# ── internode drawing ──

def draw_internode(part):
    turtle = part.plant.turtle
    if turtle is None:
        return
    zAngle = part.internodeAngle
    if part.phytomerAttachedTo is not None:
        if part.phytomerAttachedTo.leftBranchPlantPart is part:
            zAngle = zAngle + part.plant.pMeristem.branchingAngle
        elif part.phytomerAttachedTo.rightBranchPlantPart is part:
            zAngle = zAngle + part.plant.pMeristem.branchingAngle
            turtle.rotateX(128)
    length = umath.max(0.0, part.propFullLength() *
                       part.plant.pInternode.lengthAtOptimalFinalBiomassAndExpansion_mm)
    width = umath.max(0.0, part.propFullWidth() *
                      part.plant.pInternode.widthAtOptimalFinalBiomassAndExpansion_mm)
    # Species with a 0 internode-length param (e.g. maiden grass) would draw
    # every node at the origin — leaves pile at the bottom. Fall back to a
    # fraction of the petiole length so the plant still has structure.
    if length <= 0 and not part.isFirstPhytomer:
        petiole = getattr(part.plant.pLeaf, "petioleLengthAtOptimalBiomass_mm", 30.0) or 30.0
        length = petiole * 0.25 * umath.max(0.1, part.propFullLength())
    color = part.internodeColor if part.internodeColor else (60, 120, 60)
    _draw_stem_segment(part, length, width, zAngle, 0, color, kDontTaper,
                       kExportPartInternode)


def _draw_stem_segment(part, length, width, angleZ, angleY, color, taperIndex, dxfIndex):
    turtle = part.plant.turtle
    if turtle is None or length <= 0:
        return
    pGeneral = part.plant.pGeneral
    lineDivisions = max(1, int(getattr(pGeneral, "lineDivisions", 3)))
    realAngleZ = angleZ
    realAngleY = angleY
    if lineDivisions > 1:
        turnPortionZ = realAngleZ / lineDivisions
        turnPortionY = realAngleY / lineDivisions
        drawPortion = length / lineDivisions
    else:
        turnPortionZ = realAngleZ
        turnPortionY = realAngleY
        drawPortion = length
    startWidth = width
    if taperIndex > 0:
        endWidth = startWidth * taperIndex / 100.0
    else:
        endWidth = width

    turtle.setLineColor(color)
    for i in range(lineDivisions):
        isLast = (i >= lineDivisions - 1)
        if not isLast:
            segmentTurnZ = turnPortionZ
            segmentTurnY = turnPortionY
            segmentLength = drawPortion
        else:
            segmentTurnZ = realAngleZ - (turnPortionZ * (lineDivisions - 1))
            segmentTurnY = realAngleY - (turnPortionY * (lineDivisions - 1))
            segmentLength = length - (drawPortion * (lineDivisions - 1))
        if taperIndex > 0 and lineDivisions > 1:
            startPortionWidth = startWidth - (i / (lineDivisions - 1)) * (startWidth - endWidth)
            if not isLast:
                endPortionWidth = startWidth - ((i + 1) / (lineDivisions - 1)) * (startWidth - endWidth)
            else:
                endPortionWidth = endWidth
        else:
            startPortionWidth = width
            endPortionWidth = width
        turtle.rotateY(segmentTurnY)
        turtle.rotateZ(segmentTurnZ)
        # draw pipe for this segment
        start_pos = turtle.position()
        turtle.setLineWidth(startPortionWidth)
        turtle.moveInMillimeters(segmentLength)
        end_pos = turtle.position()
        turtle.drawPipe(start_pos, end_pos,
                        startPortionWidth * turtle.scale_pixelsPerMm * 0.5,
                        endPortionWidth * turtle.scale_pixelsPerMm * 0.5,
                        6, color)


# ── leaf drawing ──

def draw_leaf(leaf, direction):
    turtle = leaf.plant.turtle
    if turtle is None or leaf.hasFallenOff:
        return
    turtle.push()
    if direction == kDirectionRight:
        turtle.rotateX(128)
    pLeaf = leaf.plant.pLeaf
    propFullSize = umath.min(1.0, leaf.liveBiomass_pctMPB /
                             max(0.001, pLeaf.optimalBiomass_pctMPB))
    length = pLeaf.petioleLengthAtOptimalBiomass_mm * propFullSize
    if leaf.isSeedlingLeaf:
        length = length / 2
    width = pLeaf.petioleWidthAtOptimalBiomass_mm * propFullSize
    angle = pLeaf.petioleAngle
    petioleColor = pLeaf.petioleColor if pLeaf.petioleColor else (60, 120, 60)

    if leaf.isSeedlingLeaf:
        _draw_stem_segment(leaf, length, width, angle, 0, petioleColor,
                           pLeaf.petioleTaperIndex, kExportPartPetiole)
        scale = propFullSize * (getattr(leaf.plant.pSeedlingLeaf, "scaleAtFullSize", 20) / 100.0)
        _draw_leaf_tdo(leaf, scale, seedling=True)
    else:
        if getattr(pLeaf, "stipuleTdoParams", None) is not None and \
                getattr(leaf.plant.params.stipuleTdoParams, "scaleAtFullSize", 0) > 0:
            _draw_stipule(leaf)
        if pLeaf.compoundNumLeaflets <= 1:
            _draw_stem_segment(leaf, length, width, angle, 0, petioleColor,
                               pLeaf.petioleTaperIndex, kExportPartPetiole)
            _draw_leaflet(leaf, _leaf_scale(leaf))
        else:
            _draw_compound_leaf(leaf, length, width, angle, petioleColor)
    turtle.pop()


def _draw_leaf_tdo(leaf, scale, seedling):
    turtle = leaf.plant.turtle
    if turtle is None:
        return
    pLeaf = leaf.plant.pLeaf
    if seedling:
        tdo = getattr(leaf.plant.pSeedlingLeaf, "leafTdoParams", None)
        if tdo is None or tdo.object3D is None:
            return
        faceColor = tdo.faceColor if tdo.faceColor else (50, 200, 50)
        turtle.rotateX(_angle_with_sway(leaf, tdo.xRotationBeforeDraw))
        turtle.rotateY(_angle_with_sway(leaf, tdo.yRotationBeforeDraw))
        turtle.rotateZ(_angle_with_sway(leaf, tdo.zRotationBeforeDraw))
    else:
        tdo = leaf.plant.params.leafTdoParams
        if tdo is None or tdo.object3D is None:
            return
        faceColor = tdo.faceColor if tdo.faceColor else (50, 200, 50)
        turtle.rotateX(_angle_with_sway(leaf, tdo.xRotationBeforeDraw))
        turtle.rotateY(_angle_with_sway(leaf, tdo.yRotationBeforeDraw))
        turtle.rotateZ(_angle_with_sway(leaf, tdo.zRotationBeforeDraw))
    turtle.rotateZ(-64)
    r_tdo = resolve_tdo(leaf.plant, tdo.object3D)
    if r_tdo is not None:
        turtle.drawTriangleSet(r_tdo.points, r_tdo.triangles, scale, faceColor)


def _draw_stipule(leaf):
    turtle = leaf.plant.turtle
    if turtle is None:
        return
    pLeaf = leaf.plant.pLeaf
    tdoParams = leaf.plant.params.stipuleTdoParams
    turtle.push()
    turtle.rotateX(_angle_with_sway(leaf, tdoParams.xRotationBeforeDraw))
    turtle.rotateY(_angle_with_sway(leaf, tdoParams.yRotationBeforeDraw))
    turtle.rotateZ(_angle_with_sway(leaf, tdoParams.zRotationBeforeDraw))
    propFullSize = umath.min(1.0, leaf.liveBiomass_pctMPB /
                             max(0.001, pLeaf.optimalBiomass_pctMPB))
    scale = propFullSize * (tdoParams.scaleAtFullSize / 100.0)
    if tdoParams.object3D is not None:
        color = tdoParams.faceColor if tdoParams.faceColor else (50, 200, 50)
        r_tdo = resolve_tdo(leaf.plant, tdoParams.object3D)
        if r_tdo is not None:
            turtle.drawTriangleSet(r_tdo.points, r_tdo.triangles, scale, color)
    turtle.pop()


def _prop_full_size(leaf):
    pLeaf = leaf.plant.pLeaf
    return umath.min(1.0, leaf.liveBiomass_pctMPB /
                     max(0.001, pLeaf.optimalBiomass_pctMPB))


def _leaf_scale(leaf):
    """scale = propFullSize * leafTdoParams.scaleAtFullSize / 100 (original)."""
    pfs = _prop_full_size(leaf)
    tdo = leaf.plant.params.leafTdoParams
    scale_at_full = tdo.scaleAtFullSize if tdo else 30.0
    return pfs * scale_at_full / 100.0


def _draw_leaflet(leaf, scale):
    """DrawLeafOrLeaflet port: TDO at scale with rotations + rotateZ(-64)."""
    turtle = leaf.plant.turtle
    pLeaf = leaf.plant.pLeaf
    tdo = leaf.plant.params.leafTdoParams
    if tdo is None or tdo.object3D is None:
        return
    r_tdo = resolve_tdo(leaf.plant, tdo.object3D)
    if r_tdo is None:
        # fallback: try the library default object so leaves always show
        r_tdo = resolve_tdo(leaf.plant, "Default 3D object")
        if r_tdo is None:
            return
    turtle.rotateX(_angle_with_sway(leaf, tdo.xRotationBeforeDraw))
    turtle.rotateY(_angle_with_sway(leaf, tdo.yRotationBeforeDraw))
    turtle.rotateZ(_angle_with_sway(leaf, tdo.zRotationBeforeDraw))
    turtle.rotateZ(-64)  # pull leaf up to plane of petiole
    faceColor = tdo.faceColor if tdo.faceColor else (50, 200, 50)
    turtle.drawTriangleSet(r_tdo.points, r_tdo.triangles, scale, faceColor)


def _draw_compound_leaf(leaf, length, width, angle, petioleColor):
    """Faithful port of drawCompoundLeafPinnate/Palmate."""
    turtle = leaf.plant.turtle
    if turtle is None:
        return
    pLeaf = leaf.plant.pLeaf
    numLeaflets = int(pLeaf.compoundNumLeaflets)
    if numLeaflets <= 1:
        return
    scale = _leaf_scale(leaf)
    pfs = _prop_full_size(leaf)
    rachis_ratio = getattr(pLeaf, "compoundRachisToPetioleRatio", 30.0)
    pinnate = int(getattr(pLeaf, "compoundPinnateOrPalmate", 0))

    def _leaflet_length():
        return pLeaf.petioleLengthAtOptimalBiomass_mm * pfs * rachis_ratio / 100.0

    if pinnate == 0:  # pinnate: leaflets along rachis, alternate ±32°
        for i in range(numLeaflets, 0, -1):
            turtle.push()
            if i != 1:
                turtle.rotateX(32 if (i % 2 == 0) else -32)
            _draw_stem_segment(leaf, _leaflet_length(), width, 0, 0,
                               petioleColor, kDontTaper, kExportPartPetiole)
            _draw_leaflet(leaf, scale)
            turtle.pop()
    else:  # palmate: leaflets radiate from a point
        angle_one = umath.safedivExcept(64, numLeaflets, 0)
        for i in range(numLeaflets, 0, -1):
            turtle.push()
            if i == 1:
                leaflet_angle = 0
            elif i % 2 == 1:
                leaflet_angle = angle_one * i * -1
            else:
                leaflet_angle = angle_one * i
            _draw_stem_segment(leaf, _leaflet_length(), width, 0, leaflet_angle,
                               petioleColor, kDontTaper, kExportPartPetiole)
            _draw_leaflet(leaf, scale)
            turtle.pop()


def _angle_with_sway(part, angle):
    """Add random sway to a draw angle (deterministic via plant RNG)."""
    rng = part.plant.randomNumberGenerator
    sway = getattr(part.plant.pGeneral, "randomSway", 0.0)
    if sway == 0:
        return angle
    return angle + (rng.zeroToOne() - 0.5) * 2.0 * sway * 256 / 360


# ── meristem / inflorescence TDO drawing ──

def draw_meristem(meristem):
    plant = meristem.plant
    turtle = plant.turtle
    if turtle is None or meristem.isApical:
        return
    bud = plant.pAxillaryBud
    if bud is None or bud.scaleAtFullSize == 0 or bud.object3D is None:
        return
    daysToFullSize = 5
    scale = (bud.scaleAtFullSize / 100.0) * umath.min(1.0, meristem.age / daysToFullSize)
    if scale <= 0:
        return
    numParts = 5
    color = bud.faceColor if bud.faceColor else (50, 100, 50)
    for i in range(numParts):
        turtle.rotateX(256 / numParts)
        turtle.push()
        turtle.rotateZ(-64)
        turtle.rotateX(bud.xRotationBeforeDraw)
        turtle.rotateY(bud.yRotationBeforeDraw)
        turtle.rotateZ(bud.zRotationBeforeDraw)
        r_tdo = resolve_tdo(plant, bud.object3D)
        if r_tdo is not None:
            turtle.drawTriangleSet(r_tdo.points, r_tdo.triangles, scale, color)
        turtle.pop()


def draw_inflorescence(inflor):
    plant = inflor.plant
    turtle = plant.turtle
    if turtle is None:
        return
    p = plant.pInflor[inflor.gender]
    faceColor = (200, 200, 60)
    tdo_name = None
    petal_scale = 20.0
    petal_angle = 0.0
    if isinstance(p, dict) and "tdoParams" in p:
        tp = p["tdoParams"]
        for k in tp:
            tdo_obj = tp[k]
            if tdo_obj and getattr(tdo_obj, "object3D", None) is not None:
                tdo_name = tdo_obj.object3D
                faceColor = getattr(tdo_obj, "faceColor", None) or (200, 200, 60)
                petal_scale = getattr(tdo_obj, "scaleAtFullSize", 20.0) or 20.0
                petal_angle = getattr(tdo_obj, "pullBackAngle", 0.0) or 0.0
                break
    scale = inflor.fractionOfOptimalSizeWhenCreated
    r_tdo = resolve_tdo(plant, tdo_name) if tdo_name else None
    turtle.setLineWidth(8.0)
    turtle.drawInMillimeters(16 * scale)  # inflorescence stalk (visible thickness)
    if r_tdo is not None:
        numFlowers = int(min(8, max(1, inflor.numFlowers)))
        # draw_scale: petal_scale / 50 gives visible flower size (not / 100)
        draw_scale = scale * petal_scale / 50.0
        for i in range(numFlowers):
            turtle.push()
            turtle.rotateX(i * 256 / max(1, numFlowers))
            turtle.rotateZ(-64 + petal_angle)
            turtle.drawTriangleSet(r_tdo.points, r_tdo.triangles, draw_scale, faceColor)
            turtle.pop()


def draw_flower(flower):
    pass
