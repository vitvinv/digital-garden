"""N-panel UI for the PlantStudio addon.

Layout:
  - Plant list (Blender-style UIList of all plants in the scene)
  - Add Plant button + delete + seed
  - Wizard: step navigation (Meristems/Internodes/Leaves/...),
    presets grouped by category, live knobs for the current step
"""

import bpy
from bpy.types import Panel, UIList, PropertyGroup
from bpy.props import (StringProperty, IntProperty, PointerProperty,
                       EnumProperty, CollectionProperty)

from .operators import get_library


def _species_items(self, context):
    """Dynamic enum items, grouped by category (.pla file name).
    Tutorial categories are excluded."""
    try:
        lib, _ = get_library()
        by_cat = lib.names_by_category() if lib else {}
    except Exception:
        by_cat = {}
    items = []
    skip_cats = [c for c in by_cat if "tutorial" in c.lower()]
    for cat in sorted(by_cat.keys()):
        if cat in skip_cats:
            continue
        names = by_cat[cat]
        if names:
            items.append(("", cat, "", 'NONE', 0))
            for n in names[:100]:
                items.append((n, n, ""))
    if not items:
        items.append(("maiden grass", "maiden grass", ""))
    return items


class PS_MT_presets(bpy.types.Menu):
    """Preset picker: submenus per .pla category."""
    bl_label = "PlantStudio Presets"
    bl_idname = "PS_MT_presets"

    def draw(self, context):
        layout = self.layout
        try:
            lib, _ = get_library()
            by_cat = lib.names_by_category() if lib else {}
        except Exception:
            by_cat = {}
        skip_cats = [c for c in by_cat if "tutorial" in c.lower()]
        for cat in sorted(by_cat.keys()):
            if cat in skip_cats:
                continue
            names = by_cat[cat]
            if not names:
                continue
            menu_id = "PS_MT_preset_" + cat.replace(" ", "_").replace("-", "_")
            layout.menu(menu_id, text=cat, icon='FILE_FOLDER')


def _make_category_draw(cat, names):
    def draw(self, context):
        layout = self.layout
        for n in names[:100]:
            op = layout.operator("plantstudio.load_preset", text=n)
            op.species_name = n
    return draw


def register_category_menus():
    """Register one submenu class per .pla category."""
    try:
        lib, _ = get_library()
        by_cat = lib.names_by_category() if lib else {}
    except Exception:
        by_cat = {}
    skip_cats = [c for c in by_cat if "tutorial" in c.lower()]
    for cat in sorted(by_cat.keys()):
        if cat in skip_cats:
            continue
        names = by_cat[cat]
        if not names:
            continue
        menu_id = "PS_MT_preset_" + cat.replace(" ", "_").replace("-", "_")
        if menu_id in dir(bpy.types):
            continue
        cls = type(
            menu_id,
            (bpy.types.Menu,),
            {
                "bl_idname": menu_id,
                "bl_label": cat,
                "draw": _make_category_draw(cat, names),
            },
        )
        bpy.utils.register_class(cls)


def _seed_update(self, context):
    """Seed changed — rebuild the selected plant with the new seed."""
    knobs = context.scene.ps_wizard_knobs
    coll = bpy.data.collections.get("PlantStudio Plants")
    if coll is not None and 0 <= knobs.selected_index < len(coll.objects):
        obj = coll.objects[knobs.selected_index]
        obj["ps_seed"] = int(self.seed)
        knobs.dirty = True
        from .wizard import _ensure_timer
        _ensure_timer()


class PSProperties(bpy.types.PropertyGroup):
    species_name: EnumProperty(name="Species", items=_species_items)
    base_species: StringProperty(name="Base species", default="")
    seed: IntProperty(name="Seed", default=280, min=1, max=99999, update=_seed_update)
    day: IntProperty(name="Age (days)", default=60, min=0, max=1000)


class PSPlantListItem(PropertyGroup):
    name: StringProperty()


class PSPlantList(PropertyGroup):
    plants: CollectionProperty(type=PSPlantListItem)


def sync_plant_list(scene):
    """Reconcile the ps_plant_list collection with the scene collection.

    Must NOT be called during panel draw (Blender forbids writing to
    ID data in draw). Called from operators and a depsgraph handler.
    """
    from .scene_bridge import COLLECTION_NAME
    try:
        plist = scene.ps_plant_list
    except AttributeError:
        return
    coll = bpy.data.collections.get(COLLECTION_NAME)
    names = [o.name for o in coll.objects] if coll else []
    current = [i.name for i in plist.plants]
    if names != current:
        plist.plants.clear()
        for n in names:
            item = plist.plants.add()
            item.name = n


@bpy.app.handlers.persistent
def _depsgraph_sync_plant_list(scene, depsgraph):
    """Keep the plant list in sync when objects are added/removed/renamed."""
    try:
        sync_plant_list(scene)
    except Exception:
        pass


class PS_UL_plants(UIList):
    """Blender-style list of plants in the scene."""

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "name", text="", emboss=False,
                        icon='OUTLINER_OB_MESH')
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='OUTLINER_OB_MESH')


class PS_PT_panel(Panel):
    bl_label = "PlantStudio"
    bl_idname = "PS_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PlantStudio"

    def draw(self, context):
        try:
            self._draw(context)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.layout.label(text=f"PlantStudio error: {e}", icon='ERROR')

    def _draw(self, context):
        from .scene_bridge import COLLECTION_NAME
        from .wizard import (KNOB_DEFS, knobs_for_step, STEP_NAMES,
                             placement_enabled)

        layout = self.layout
        props = context.scene.ps_props
        knobs = context.scene.ps_wizard_knobs
        plist = context.scene.ps_plant_list

        coll = bpy.data.collections.get(COLLECTION_NAME)
        plants = list(coll.objects) if coll else []
        selected_valid = (0 <= knobs.selected_index < len(plants))

        # ── Plant list ──
        box = layout.box()
        box.label(text=f"Plants ({len(plants)})", icon='OUTLINER_OB_MESH')
        box.template_list("PS_UL_plants", "", plist, "plants",
                          knobs, "selected_index")
        row = box.row(align=True)
        row.operator("plantstudio.add_plant", text="Add Plant", icon='ADD')
        row.operator("plantstudio.delete_plant", text="", icon='TRASH')
        row2 = box.row(align=True)
        row2.label(text="Seed:")
        row2.prop(props, "seed", text="")

        # ── Wizard (selected plant) ──
        if selected_valid:
            obj = plants[knobs.selected_index]
            box = layout.box()
            box.label(text=f"Wizard — {obj.name}", icon='TOOL_SETTINGS')

            # preset row (category-grouped menu)
            row = box.row(align=True)
            row.label(text="Preset:", icon='PRESET')
            row.menu("PS_MT_presets", text="Load", icon='FILE_FOLDER')
            op = row.operator("plantstudio.save_preset", text="", icon='FILE_TICK')
            op.plant_obj_name = obj.name

            box.prop(knobs, "knob_day", text="Age (days)")

            # all wizard sections in one panel, in order
            can_repro = placement_enabled(knobs)
            for s, section_name in enumerate(STEP_NAMES):
                if s >= 5 and not can_repro:
                    continue  # inflor drawing / flowers / fruits hidden
                sub = box.box()
                sub.label(text=section_name, icon='OPTIONS')
                col = sub.column(align=True)
                col.scale_y = 0.7
                for prop_name, _path, label, _lo, _hi, _default, kstep in KNOB_DEFS:
                    if kstep != s:
                        continue
                    col.prop(knobs, prop_name, text=label)
        else:
            box = layout.box()
            box.label(text="No plant selected.", icon='INFO')
            box.label(text="Click Add Plant to create one.")


def register_panel_classes():
    pass
