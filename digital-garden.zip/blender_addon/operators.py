"""Blender operators for the PlantStudio addon."""

import os
import json
import time
import bpy
from bpy.types import Operator
from bpy.props import IntProperty, StringProperty, BoolProperty, EnumProperty

from .core.plant_library import SpeciesLibrary
from .core.tdo_parser import TdoLibrary
from .scene_bridge import (ensure_collection, build_plant_object,
                           COLLECTION_NAME, plant_object_name)

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
USER_PRESETS_DIR = os.path.join(DATA_DIR, "user-presets")

# module-level cache: parsing 9 .pla files on every UI draw is slow
_lib_cache = None
_tdo_cache = None


def clear_library_cache():
    global _lib_cache, _tdo_cache
    _lib_cache = None
    _tdo_cache = None


def get_library():
    """Get the cached species library + tdo library (parsed once)."""
    global _lib_cache, _tdo_cache
    if _lib_cache is None:
        _lib_cache = SpeciesLibrary(DATA_DIR)
    if _tdo_cache is None:
        path = os.path.join(DATA_DIR, "3D object library.tdo")
        _tdo_cache = TdoLibrary.from_file(path) if os.path.exists(path) else None
    return _lib_cache, _tdo_cache


def _default_species():
    """Return a minimal species object with normalized default params."""
    from .core.params import PlantParams
    from .core.normalize import normalize_params
    class _S:
        def __init__(self):
            self.params = PlantParams()
            self.name = "plant"
    s = _S()
    normalize_params(s.params)
    return s


def _get_species(name):
    """Get a species by name (library or default)."""
    lib, _ = get_library()
    s = lib.get(name)
    if s is not None:
        return s
    return _default_species()


def _species_items(self, context):
    try:
        lib, _ = get_library()
        names = lib.names() if lib else []
    except Exception:
        names = []
    items = [(n, n, n) for n in names[:500]]
    if not items:
        items.append(("maiden grass", "maiden grass", "fallback"))
    return items


def get_base_species(context, name=None):
    """Resolve the base species for a new plant: library species by name
    (from a loaded preset), falling back to generic defaults."""
    lib, _ = get_library()
    if not name:
        name = context.scene.ps_props.base_species
    s = lib.get(name) if name else None
    if s is not None:
        return s
    return _default_species()


class PS_OT_add_plant(Operator):
    bl_idname = "plantstudio.add_plant"
    bl_label = "Add Plant"
    bl_description = "Create a plant with the current wizard parameters"

    def execute(self, context):
        props = context.scene.ps_props
        knobs = context.scene.ps_wizard_knobs
        _, tdo_lib = get_library()
        from .wizard import apply_knobs_to_params, save_knobs_to_obj
        species = get_base_species(context)
        params = apply_knobs_to_params(species, knobs)
        coll = ensure_collection(COLLECTION_NAME)
        obj = build_plant_object(params, props.seed, props.day, coll, tdo_lib)
        save_knobs_to_obj(obj, knobs)
        obj["ps_base_species"] = getattr(species, "name", "plant")
        knobs.selected_index = len(coll.objects) - 1
        from .ui_panel import sync_plant_list
        sync_plant_list(context.scene)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        self.report({'INFO'}, f"Added {obj.name} ({len(obj.data.polygons)} faces)")
        return {'FINISHED'}


class PS_OT_load_preset(Operator):
    bl_idname = "plantstudio.load_preset"
    bl_label = "Load Preset"
    bl_description = "Overwrite the selected plant's parameters with a library preset"
    species_name: EnumProperty(name="Species", items=_species_items)

    def execute(self, context):
        knobs = context.scene.ps_wizard_knobs
        lib, _ = get_library()
        species = lib.get(self.species_name)
        if species is None:
            self.report({'ERROR'}, f"Species '{self.species_name}' not found")
            return {'CANCELLED'}
        # remember the preset as the base for new plants
        context.scene.ps_props.base_species = self.species_name
        from .wizard import load_knobs_from_params, _ensure_timer
        load_knobs_from_params(species, knobs)
        knobs.dirty = True
        _ensure_timer()
        self.report({'INFO'}, f"Loaded preset: {self.species_name}")
        return {'FINISHED'}


class PS_OT_wizard_step(Operator):
    bl_idname = "plantstudio.wizard_step"
    bl_label = "Wizard Step"
    bl_description = "Navigate the plant wizard"
    step: IntProperty(name="Step", default=0)

    def execute(self, context):
        knobs = context.scene.ps_wizard_knobs
        from .wizard import STEP_NAMES, placement_enabled
        can_repro = placement_enabled(knobs)
        step = max(0, min(7, self.step))
        # skip steps 5-7 if inflorescence placement disabled
        if not can_repro and step >= 5:
            step = 4
        knobs.wizard_step = step
        return {'FINISHED'}


class PS_OT_save_preset(Operator):
    bl_idname = "plantstudio.save_preset"
    bl_label = "Save Preset"
    bl_description = "Save the selected plant's parameters as a preset file"
    plant_obj_name: StringProperty(name="Plant", default="")

    def execute(self, context):
        knobs = context.scene.ps_wizard_knobs
        name = self.plant_obj_name or "preset"
        preset = {
            "name": name,
            "knobs": {},
        }
        from .wizard import KNOB_DEFS
        for prop_name, _path, _label, _lo, _hi, _default, _step in KNOB_DEFS:
            preset["knobs"][prop_name] = float(getattr(knobs, prop_name))
        os.makedirs(USER_PRESETS_DIR, exist_ok=True)
        ts = time.strftime("%Y%m%d-%H%M%S")
        path = os.path.join(USER_PRESETS_DIR, f"{name}-{ts}.json")
        with open(path, "w") as f:
            json.dump(preset, f, indent=2)
        self.report({'INFO'}, f"Saved preset to {path}")
        return {'FINISHED'}


def _get_species(name):
    """Get a species by name (library or default)."""
    lib, _ = get_library()
    s = lib.get(name)
    if s is not None:
        return s
    return _default_species()


class PS_OT_regrow(Operator):
    bl_idname = "plantstudio.regrow"
    bl_label = "Grow To Age"
    bl_description = "Rebuild the selected plant at its target day"

    def execute(self, context):
        obj = context.active_object
        if obj is None or "ps_species" not in obj:
            self.report({'ERROR'}, "Select a PlantStudio plant")
            return {'CANCELLED'}
        _, tdo_lib = get_library()
        species = _get_species(obj["ps_species"])
        day = int(obj["ps_day"])
        seed = int(obj["ps_seed"])
        new_obj = build_plant_object(species, seed, day,
                                     obj.users_collection[0], tdo_lib)
        new_obj.matrix_world = obj.matrix_world
        bpy.data.objects.remove(obj, do_unlink=True)
        context.view_layer.objects.active = new_obj
        new_obj.select_set(True)
        self.report({'INFO'}, f"Regrew to day {day}")
        return {'FINISHED'}


class PS_OT_step_day(Operator):
    bl_idname = "plantstudio.step_day"
    bl_label = "Step Day"
    bl_description = "Advance the selected plant by one day"

    def execute(self, context):
        obj = context.active_object
        if obj is None or "ps_day" not in obj:
            self.report({'ERROR'}, "Select a PlantStudio plant")
            return {'CANCELLED'}
        obj["ps_day"] = int(obj["ps_day"]) + 1
        bpy.ops.plantstudio.regrow()
        return {'FINISHED'}


class PS_OT_delete_plant(Operator):
    bl_idname = "plantstudio.delete_plant"
    bl_label = "Delete Plant"
    bl_description = "Remove the selected plant from the scene"

    def execute(self, context):
        knobs = context.scene.ps_wizard_knobs
        coll = bpy.data.collections.get(COLLECTION_NAME)
        if coll is None or not (0 <= knobs.selected_index < len(coll.objects)):
            self.report({'ERROR'}, "Select a plant in the list first")
            return {'CANCELLED'}
        obj = coll.objects[knobs.selected_index]
        bpy.data.objects.remove(obj, do_unlink=True)
        knobs.selected_index = min(knobs.selected_index, len(coll.objects) - 1)
        from .ui_panel import sync_plant_list
        sync_plant_list(context.scene)
        return {'FINISHED'}


class PS_OT_random_seed(Operator):
    bl_idname = "plantstudio.random_seed"
    bl_label = "Randomize Seed"

    def execute(self, context):
        import random
        context.scene.ps_props.seed = random.randint(1, 9999)
        return {'FINISHED'}
